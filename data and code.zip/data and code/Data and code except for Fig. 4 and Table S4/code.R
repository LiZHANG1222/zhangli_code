
setwd("C:/Users/zhang/Desktop/6. 2021.10兰州病害与植物氮吸收/3. 文稿撰写与投稿/PCE之后/for JEB/！！删除Ce数据后重新计算/data and code/Data and code except for Fig. 4 and Table S4")


data<-read.csv("data_Pathogen and N uptake.csv",header = T)
data
head(data)

library(readxl)
library(tidyverse)
library(ggsci)
library(scales)
library(sciplot)
library(ggpubr)
library(lme4)
library(lmerTest)
library(multcomp)
library(agricolae)

#######Fig. 1 Changes of plant nitrogen uptake from ammonium and nitrate with AMF and pathogen presentence/absence treatments for each species######
data$T <- as.factor(data$T)
datanew <- subset(data,SP=="QM")
datanew <- subset(data,SP=="PJ")
datanew <- subset(data,SP=="MX")
datanew <- subset(data,SP=="DD")

data.am <- subset(datanew,N_form == "AM")
data.nt <- subset(datanew,N_form == "NT")
####one-way ANOVA followed by Tukey’s HSD tests to assess the effects of six microorganism treatments (i.e., three AMF treatments × two pathogen treatments) on plant nitrogen uptake from ammonium and nitrate###
mNup <- aov(Nup ~ T, data.nt)
comparison <- TukeyHSD(mNup)
print(comparison)
library(agricolae)
result <- HSD.test(mNup,"T")
result

####plot Fig. 1###
up.am <- data.am %>% group_by(T) %>% summarise(mean = mean(Nup),
                                                se = se(Nup))
up.nt <- data.nt %>% group_by(T) %>% summarise(mean = mean(Nup),
                                                se = se(Nup))

theme_set(theme_test())

plot.up.am <- ggplot()+
  geom_bar(data = up.am,aes(x = T,y = mean,color = T,fill = T),stat = "identity",linewidth = 0.75,alpha = 0.55)+
  scale_color_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  scale_fill_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  geom_errorbar(data = up.am,aes(x = T,y = mean,ymin = mean - se,ymax = mean + se,color = T),width = 0.3,linewidth = 1.25)+
  coord_cartesian(ylim = c(0,40))+
  scale_y_continuous(breaks = seq(0,40,10))+
  theme_test()+labs(y="AM N uptake")
plot.up.am

plot.up.nt <- ggplot()+
  geom_bar(data = up.nt,aes(x = T,y = mean,color = T,fill = T),stat = "identity",linewidth = 0.75,alpha = 0.55)+
  scale_color_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  scale_fill_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  geom_errorbar(data = up.nt,aes(x = T,y = mean,ymin = mean - se,ymax = mean + se,color = T),width = 0.3,linewidth = 1.25)+
  coord_cartesian(ylim = c(0,40))+
  scale_y_continuous(breaks = seq(0,40,10))+
  theme_test()+labs(y="NT N uptake")
plot.up.nt

ggarrange(plot.up.am,plot.up.nt,ncol = 2,nrow = 2,common.legend = T,legend = "bottom")
ggsave("Fig 1-QM Nup.pdf",width = 12,height = 12)
ggsave("Fig 1-PJ Nup.pdf",width = 12,height = 12)
ggsave("Fig 1-MX Nup.pdf",width = 12,height = 12)
ggsave("Fig 1-DD Nup.pdf",width = 12,height = 12)



#######Fig. 2 Changes of plant root traits with AMF and pathogen presentence/absence treatments across species######
plant_root_traits <- data %>% select(5,12:16) %>% group_by(T) %>% summarise(mean.RL = mean(RL),se.RL = se(RL),
                                                                mean.RA = mean(RA),se.RA = se(RA),
                                                                mean.SRL = mean(SRL),se.SRL = se(SRL),
                                                                mean.SRA = mean(SRA),se.SRA = se(SRA),
                                                                mean.RTD = mean(RTD),se.RTD = se(RTD))

#anova and tukey test#
head(data)
m1<-lmer(lgRL~T+(1|SP),data)
m1<-lmer(lgRA~T+(1|SP),data)
m1<-lmer(lgSRL~T+(1|SP),data)
m1<-lmer(lgSRA~T+(1|SP),data)
m1<-lmer(RTD~T+(1|SP),data)
summary(m1)
anova(m1)
summary(glht(m1,linfct=mcp(T="Tukey")))

#plot of Fig.2#
RL <- ggplot()+
  geom_bar(data = trait,aes(x = T,y = mean.RL,color = T,fill = T),stat = "identity",linewidth = 0.75,alpha = 0.55)+
  scale_color_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  scale_fill_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  geom_errorbar(data = trait,aes(x = T,y = mean.RL,ymin = mean.RL - se.RL,ymax = mean.RL + se.RL,color = T),width = 0.3,linewidth = 1.25)+
  coord_cartesian(ylim = c(0,12000))+
  scale_y_continuous(breaks = seq(0,12000,3000))
RL

RA <- ggplot()+
  geom_bar(data = trait,aes(x = T,y = mean.RA,color = T,fill = T),stat = "identity",linewidth = 0.75,alpha = 0.55)+
  scale_color_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  scale_fill_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  geom_errorbar(data = trait,aes(x = T,y = mean.RA,ymin = mean.RA - se.RA,ymax = mean.RA + se.RA,color = T),width = 0.3,linewidth = 1.25)+
  coord_cartesian(ylim = c(0,1200))+
  scale_y_continuous(breaks = seq(0,1200,300))
RA

SRL <- ggplot()+
  geom_bar(data = trait,aes(x = T,y = mean.SRL,color = T,fill = T),stat = "identity",linewidth = 0.75,alpha = 0.55)+
  scale_color_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  scale_fill_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  geom_errorbar(data = trait,aes(x = T,y = mean.SRL,ymin = mean.SRL - se.SRL,ymax = mean.SRL + se.SRL,color = T),width = 0.3,linewidth = 1.25)+
  coord_cartesian(ylim = c(0,1200))+
  scale_y_continuous(breaks = seq(0,1200,400))
SRL

SRA <- ggplot()+
  geom_bar(data = trait,aes(x = T,y = mean.SRA,color = T,fill = T),stat = "identity",linewidth = 0.75,alpha = 0.55)+
  scale_color_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  scale_fill_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  geom_errorbar(data = trait,aes(x = T,y = mean.SRA,ymin = mean.SRA - se.SRA,ymax = mean.SRA + se.SRA,color = T),width = 0.3,linewidth = 1.25)+
  coord_cartesian(ylim = c(0,1000))+
  scale_y_continuous(breaks = seq(0,1000,200))
SRA

RTD <- ggplot()+
  geom_bar(data = trait,aes(x = T,y = mean.RTD,color = T,fill = T),stat = "identity",linewidth = 0.75,alpha = 0.55)+
  scale_color_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  scale_fill_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  geom_errorbar(data = trait,aes(x = T,y = mean.RTD,ymin = mean.RTD - se.RTD,ymax = mean.RTD + se.RTD,color = T),width = 0.3,linewidth = 1.25)+
  coord_cartesian(ylim = c(0,0.36))+
  scale_y_continuous(breaks = seq(0,0.36,0.12))
RTD

ggarrange(RL,RA,SRL,SRA,RTD,ncol = 3,nrow = 4,common.legend = T,legend = "bottom")
ggsave("Fig2.pdf",width = 18,height = 24)




#######Fig. 3 SEM #######
library(piecewiseSEM)
library(semPlot)
library(lme4)
library(lmerTest)
head(data)
dataFM <- subset(data,(AMF_T=="Fm"|AMF_T=="C"))
datanew<-subset(dataFM,(N_form =="AM"))
datanew<-subset(dataFM,(N_form =="NT"))

dataM <- subset(data,(AMF_T=="M"|AMF_T=="C"))
datanew<-subset(dataM,(N_form =="AM"))
datanew<-subset(dataM,(N_form =="NT"))

modlist = psem(
  lmer( lgNup~AMF_infecion_rate*Disease_infecion_rate+lgRA +RTD+Hm+(1|SP), datanew ),
  lmer( lgRA ~AMF_infecion_rate*Disease_infecion_rate+(1|SP),datanew ),
  lmer( RTD ~AMF_infecion_rate*Disease_infecion_rate+(1|SP),datanew ),
  lmer( Hm~AMF_infecion_rate*Disease_infecion_rate+(1|SP),datanew ),
  RTD %~~%  lgRA
  
)
summary(modlist,standardize = "scale", conditional=TRUE)




######################################Supporting information################################
######Table S2 Three-way ANOVA results of the effects of species identity (SP), AMF treatments (AMF), pathogen presence/absence (Pa) and their interactions on AMF colonization and disease severity rates#######
m1<-lm(AMF_infecion_rate ~SP*AMF_T*Dis_T,data)
anova(m1)
m1<-lm(Disease_infecion_rate~SP*AMF_T*Dis_T,data)
anova(m1)


######Table S3 Four-way ANOVA results of the effects of species identity (SP), AMF treatments (AMF), pathogen presence/absence (Pa), nitrogen forms (N form) and their interactions on plant nitrogen uptake######
m1<-lm(lgNup~SP*AMF_T*Dis_T*N_form,data)
anova(m1)


######Fig. S1  Pearson correlation matrix of plant traits######
library(gpairs)
data1<-subset(data, select = c(  lgLA,lgSLA ,Hm,   
                                 lgRL,lgRA, lgSRL,lgSRA,RTD))

gpairs(data1,
       upper.pars = list(scatter = "stats"),
       stat.pars = list(fontsize =15, signif = 0.05, verbose = F,use.color=T,insig = "blank"),##personϵ??
       lower.pars = list(scatter = "lm",color="black",lwd=2),
       diagonal = "default",
       diag.pars = list(fontsize = 10, show.hist = F),
       axis.pars = list(n.ticks = 5, fontsize = 9))


#######Fig. S3 Changes of measured AMF colonization rate (a) and disease severity rate (b) with AMF and pathogen presentence/absence treatments######

data<-read.csv("data_Pathogen and N uptake.csv",header = T)
data
head(data)
library(readxl)
library(tidyverse)
library(ggsci)
library(scales)
library(sciplot)
library(ggpubr)

####AMF colonization rate across species###
AMF_total <- data %>% select(5,7) %>% group_by(T) %>% summarise(mean.AMF_infecion_rate = mean(AMF_infecion_rate,na.rm = TRUE),
                                                            se.AMF_infecion_rate = se(AMF_infecion_rate,na.rm = TRUE))

#anova and tukey test#
library(lme4)
library(lmerTest)
library(multcomp)
m1<-lmer(AMF_infecion_rate~T+(1|SP),data)
summary(m1)
anova(m1)
summary(glht(m1,linfct=mcp(T="Tukey")))

#plot Fig. S3 AMF across species#                                             
p <- ggplot()+
  geom_bar(AMF_total,aes(x = T,y = mean.AMF_infecion_rate,color = T,fill = T),stat = "identity",linewidth = 0.75,alpha = 0.55)+
  scale_color_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  scale_fill_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  geom_errorbar(data = trait,aes(x = T,y = mean.AMF_infecion_rate,ymin = mean.AMF_infecion_rate - se.AMF_infecion_rate,
                                 ymax = mean.AMF_infecion_rate + se.AMF_infecion_rate,color = T),width = 0.3,linewidth = 1.25)+
  coord_cartesian(ylim = c(0,40))+
  scale_y_continuous(breaks = seq(0,40,10))+
  theme_test()+labs(y="Total")
p


####AMF colonization rate of each species### 
AMF_SP <- data %>% select(1,5,7) %>% group_by(SP,T) %>% summarise(mean.AMF_infecion_rate = mean(AMF_infecion_rate,na.rm = TRUE),
                                                                     se.AMF_infecion_rate = se(AMF_infecion_rate,na.rm = TRUE))

datanew <- subset(data,SP=="QM")
datanew <- subset(data,SP=="PJ")
datanew <- subset(data,SP=="MX")
datanew <- subset(data,SP=="DD")
#anova and tukey test#
mAMF <- aov(AMF_infecion_rate ~ T, datanew)
comparison <- TukeyHSD(mAMF)
print(comparison)
library(agricolae)
result <- HSD.test(mAMF,"T")
result

# plot Fig. S3 AMF each species#
pSP <- ggplot()+
  geom_bar(data = AMFSP,aes(x = T,y = mean.AMF_infecion_rate,color = T,fill = T),stat = "identity",linewidth = 0.75,alpha = 0.55)+
  scale_color_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  scale_fill_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  geom_errorbar(data = traitSP,aes(x = T,y = mean.AMF_infecion_rate,ymin = mean.AMF_infecion_rate - se.AMF_infecion_rate,
                                   ymax = mean.AMF_infecion_rate + se.AMF_infecion_rate,color = T),width = 0.3,linewidth = 1.25)+
  coord_cartesian(ylim = c(0,40))+
  scale_y_continuous(breaks = seq(0,40,10))+
  facet_wrap(. ~ SP, nrow = 1)+
  theme_test()+labs(y="SP")
pSP

####disease severity rate across species ###
data<-read.csv("data_Pathogen and N uptake.csv",header = T)
data
head(data)
library(readxl)
library(tidyverse)
library(ggsci)
library(scales)
library(sciplot)
library(ggpubr)
disease <- data %>% select(5,8) %>% group_by(T) %>% summarise(mean.Disease_infecion_rate = mean(Disease_infecion_rate,na.rm = TRUE),
                                                                se.Disease_infecion_rate = se(Disease_infecion_rate,na.rm = TRUE))

library(lme4)
library(lsmeans)
mDisease <- lmer(Disease_infecion_rate ~ T + (1|SP), data)  # 使用"SP"作为随机因子的线性混合模型
anova(mDisease)  
lsmeans(mDisease, "T") 
comparison <- lsmeans(mDisease, pairwise ~ T) 
print(comparison)

####disease severity rate of each species ###
diseaseSP <- data %>% select(1,5,8) %>% group_by(SP,T) %>% summarise(mean.Disease_infecion_rate = mean(Disease_infecion_rate,na.rm = TRUE),
                                                            se.Disease_infecion_rate = se(Disease_infecion_rate,na.rm = TRUE))

datanew <- subset(data,SP=="QM")
datanew <- subset(data,SP=="PJ")
datanew <- subset(data,SP=="MX")
datanew <- subset(data,SP=="DD")
#anova and tukey test#
mDisease <- aov(Disease_infecion_rate ~ T, datanew)
comparison <- TukeyHSD(mDisease)
print(comparison)
library(agricolae)
result <- HSD.test(mDisease,"T")
result
              
# plot Fig. S3 disease across species#                                            
p <- ggplot()+
  geom_bar(data = disease,aes(x = T,y = mean.Disease_infecion_rate,color = T,fill = T),stat = "identity",linewidth = 0.75,alpha = 0.55)+
  scale_color_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  scale_fill_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  geom_errorbar(data = trait,aes(x = T,y = mean.Disease_infecion_rate,ymin = mean.Disease_infecion_rate - se.Disease_infecion_rate,
                                 ymax = mean.Disease_infecion_rate + se.Disease_infecion_rate,color = T),width = 0.3,linewidth = 1.25)+
  coord_cartesian(ylim = c(0,2.0))+
  scale_y_continuous(breaks = seq(0,2.0,0.05))+
  theme_test()+labs(y="Total")
p

# plot Fig. S3 disease each species#
pSP <- ggplot()+
  geom_bar(data = diseaseSP,aes(x = T,y = mean.Disease_infecion_rate,color = T,fill = T),stat = "identity",linewidth = 0.75,alpha = 0.55)+
  scale_color_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  scale_fill_manual(values = c("#0073C2FF","#003C67FF","#EFC000FF","#8F7700FF","#CD534CFF","#A73030FF"))+
  geom_errorbar(data = traitSP,aes(x = T,y = mean.Disease_infecion_rate,ymin = mean.Disease_infecion_rate - se.Disease_infecion_rate,
                                 ymax = mean.Disease_infecion_rate + se.Disease_infecion_rate,color = T),width = 0.3,linewidth = 1.25)+
  coord_cartesian(ylim = c(0,2))+
  scale_y_continuous(breaks = seq(0,2,0.5))+
  facet_wrap(. ~ SP, nrow = 1)+
  theme_test()+labs(y="SP")
pSP

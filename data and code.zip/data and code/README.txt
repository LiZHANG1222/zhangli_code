This file includes all the data and code of the paper about "Tripartite interactions among plants, pathogens, and AMF" for the editor and reviewers to review.

The descriptions of the column names of data (excel name: data_Pathogen and N uptake) we used for statistical analysis.

SP: species name
QM: Bromus japonicus	
PJ: Elymus nutans
MX: Medicago sativa
DD: Glycine max
AMF_T: AMF treatments (control, Funneliformis mosseae, and mixed strain of F. mosseae and Claroideoglomus etunicatum)
Fm: Funneliformis mosseae colonization treatment
M: mixed strain of F. mosseae and Claroideoglomus etunicatum colonization treatment
C: AMF- or pathogen free-control
Dis_T: pathogen treatments (one pathogen and a pathogen-free control)
Pa: pathogen infection treatment
N_form: N form of plant uptake
AM:	NH4+
NT:	NO3-
T: Treatment
CK: AMF- and pathogen free-control; Pa: AMF-free-control with pathogen presence; Fm: F. mosseae colonization with pathogen absence; FmPa: F. mosseae colonization with pathogen presence; M: mixed-strain inoculum of C. etunicatum and F. mosseae colonization with pathogen absence; MPa: mixed-strain inoculum colonization with pathogen presence.
rep: Replicates
AMF_infecion_rate: measured AMF colonization rates
Disease_infecion_rate: measured measured disease severity rates
lgLA: log10-transformed leaf area 
lgSLA: log10-transformed specific leaf area
Hm: plant maximum height
RL: root length
RA: root area
SRL: specific root length
SRA: specific root area
RTD: root tissue density
lgRL: log10-transformed root length
lgRA: log10-transformed root area
lgSRL: log10-transformed specific root length
lgSRA: log10-transformed specific root area
Nup: Plant nitrogen uptake
lgNup: log10-transformed plant nitrogen uptake



setwd("C:/Users/zhang/Desktop/6. 2021.10兰州病害与植物氮吸收/3. 文稿撰写与投稿/PCE之后/for JEB/！！删除Ce数据后重新计算/data and code/Preference")

data<-read.csv("data_Pathogen and N uptake.csv",header = T)
data
head(data)

#######the mean and sd values of root traits######
mean_trait<-aggregate(cbind(RL,RA,SRL,SRA,RTD
                      )~ SP+ AMF_T+ Dis_T, data, mean)
mean_trait
write.csv(mean_trait,file="Result_mean_trait.csv",row.names=T)

sd_trait<-aggregate(cbind( RL,RA,SRL,SRA,RTD
                      )~ SP+ AMF_T+ Dis_T, data, sd)
sd_trait
write.csv(sd_trait,file="Result_sd_trait.csv",row.names=T)

#######the mean and sd values of plant ammounium and nitrate uptake######
###ammounium uptake###
dataAM<- subset(data,(N.form=="AM"))
dataAM
mean_AM<-aggregate(cbind(Nup
                         ) ~ SP+ AMF_T+ Dis_T, dataAM, mean)
mean_AM
write.csv(mean_AM,file="Result_mean_AM.csv",row.names=T)

sd_AM<-aggregate(cbind(Nup
) ~ SP+ AMF_T+ Dis_T, dataAM, sd)
sd_AM
write.csv(sd_AM,file="Result_sd_AM.csv",row.names=T)

###nitrate uptake###
dataNT<- subset(data,(N.form=="NT"))
dataNT
mean_NT<-aggregate(cbind(Nup
) ~ SP+ AMF_T+ Dis_T, dataNT, mean)
mean_NT
write.csv(mean_NT,file="Result_mean_NT.csv",row.names=T)

sd_NT<-aggregate(cbind(Nup
) ~ SP+ AMF_T+ Dis_T, dataNT, sd)
sd_NT
write.csv(sd_NT,file="Result_sd_NT.csv",row.names=T)


######sma analysis######
pre<-read.csv("for sma.csv",header = T)
pre
head(pre)

library(smatr)
reg1<-sma(PreNup~RL,pre)
reg2<-sma(PreNup~RA,pre)
reg3<-sma(PreNup~SRL,pre)
reg4<-sma(PreNup~SRA,pre)
reg5<-sma(PreNup~RTD,pre)

a<-rbind(reg1$groupsummary,reg2$groupsummary,reg3$groupsummary,reg4$groupsummary,reg5$groupsummary)
a
write.csv(a,file="Result_sma.csv",row.names=T)


###########################plot preference~trait ###################################

par(mfrow=c(2,2))

Data<-read.csv("RL for preference plot.csv",header = T)
Data
Data<-read.csv("RA for preference plot.csv",header = T)
Data
Data<-read.csv("SRL for preference plot.csv",header = T)
Data
Data<-read.csv("SRA for preference plot.csv",header = T)
Data

attach(Data)
head(Data)

x1 <- x_mean - x_sd
x2 <- x_mean + x_sd
y1 <- y_mean - y_sd
y2 <- y_mean + y_sd

xr <- range(c(x1, x2))
yr <- range(c(y1, y2))
z  <- 100
x_p <- (xr[2]-xr[1])/z
y_p <- (yr[2]-yr[1])/z

x3 <- x_mean - x_p
x4 <- x_mean + x_p
y3 <- y_mean - y_p
y4 <- y_mean + y_p

par(mar=c(5,5,2,2))

plot(0, 0, xlim=xr, ylim=yr, type="n", cex.lab=1.5, cex.axis=1.5,font.lab = 2, 
     xlab="Root length", ylab="Ammonium:Nitrate preference")

for(i in 1:length(x1)){
  lines(c(x1[i], x2[i]), c(y_mean[i], y_mean[i]),col="gray50")
  lines(c(x_mean[i], x_mean[i]), c(y1[i], y2[i]),col="gray50")
  lines(c(x3[i], x4[i]), c(y1[i], y1[i]),col="gray50")
  lines(c(x3[i], x4[i]), c(y2[i], y2[i]),col="gray50")
  lines(c(x1[i], x1[i]), c(y3[i], y4[i]),col="gray50")
  lines(c(x2[i], x2[i]), c(y3[i], y4[i]),col="gray50")
  points(x_mean[i], y_mean[i], pch=16, cex=1,col="gray50")
}
abline(h = 0, v = 0, col = "gray60",lty = 3)##00处添加

library(smatr)
reg<-sma(y_mean~x_mean,Data)
reg
abline(reg,lwd=3,pch=2,cex=0.5)



plot(0, 0, xlim=xr, ylim=yr, type="n", cex.lab=1.5, cex.axis=1.5, font.lab = 2,
     xlab="Root area", ylab="Ammonium:Nitrate preference")

for(i in 1:length(x1)){
  lines(c(x1[i], x2[i]), c(y_mean[i], y_mean[i]),col="gray50")
  lines(c(x_mean[i], x_mean[i]), c(y1[i], y2[i]),col="gray50")
  lines(c(x3[i], x4[i]), c(y1[i], y1[i]),col="gray50")
  lines(c(x3[i], x4[i]), c(y2[i], y2[i]),col="gray50")
  lines(c(x1[i], x1[i]), c(y3[i], y4[i]),col="gray50")
  lines(c(x2[i], x2[i]), c(y3[i], y4[i]),col="gray50")
  points(x_mean[i], y_mean[i], pch=16, cex=1,col="gray50")
}
abline(h = 0, v = 0, col = "gray60",lty = 3)##00处添加

library(smatr)
reg<-sma(y_mean~x_mean,Data)
reg
abline(reg,lwd=3,pch=2,cex=0.5)



plot(0, 0, xlim=xr, ylim=yr, type="n", cex.lab=1.5, cex.axis=1.5, font.lab = 2,
     xlab="SRL", ylab="Ammonium:Nitrate preference")

for(i in 1:length(x1)){
  lines(c(x1[i], x2[i]), c(y_mean[i], y_mean[i]),col="gray50")
  lines(c(x_mean[i], x_mean[i]), c(y1[i], y2[i]),col="gray50")
  lines(c(x3[i], x4[i]), c(y1[i], y1[i]),col="gray50")
  lines(c(x3[i], x4[i]), c(y2[i], y2[i]),col="gray50")
  lines(c(x1[i], x1[i]), c(y3[i], y4[i]),col="gray50")
  lines(c(x2[i], x2[i]), c(y3[i], y4[i]),col="gray50")
  points(x_mean[i], y_mean[i], pch=16, cex=1,col="gray50")
}
abline(h = 0, v = 0, col = "gray60",lty = 3)##00处添加

library(smatr)
reg<-sma(y_mean~x_mean,Data)
reg
abline(reg,lwd=3,pch=2,cex=0.5)



plot(0, 0, xlim=xr, ylim=yr, type="n", cex.lab=1.5, cex.axis=1.5, font.lab = 2,
     xlab="SRA", ylab="Ammonium:Nitrate preference")


for(i in 1:length(x1)){
  lines(c(x1[i], x2[i]), c(y_mean[i], y_mean[i]),col="gray50")
  lines(c(x_mean[i], x_mean[i]), c(y1[i], y2[i]),col="gray50")
  lines(c(x3[i], x4[i]), c(y1[i], y1[i]),col="gray50")
  lines(c(x3[i], x4[i]), c(y2[i], y2[i]),col="gray50")
  lines(c(x1[i], x1[i]), c(y3[i], y4[i]),col="gray50")
  lines(c(x2[i], x2[i]), c(y3[i], y4[i]),col="gray50")
  points(x_mean[i], y_mean[i], pch=16, cex=1,col="gray50")
}
abline(h = 0, v = 0, col = "gray60",lty = 3)##00处添加

library(smatr)
reg<-sma(y_mean~x_mean,Data)
reg
abline(reg,lwd=3,pch=2,cex=0.5)







